﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova_Q_12_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("====Cardápio====");
            Console.WriteLine("100 Cachorro Quente R$ 1,10");
            Console.WriteLine("101 Bauru Simples R$ 1,30");
            Console.WriteLine("102 Bauru c/ovo R$ 1,50");
            Console.WriteLine("103 Hamburguer R$ 1,10");
            Console.WriteLine("104 Cheeseburger R$ 1,30");
            Console.WriteLine("105 Refrigerante R$ 1,00");
            Console.WriteLine("==========");
            Console.WriteLine("Qual é o codigo do pedido:"):
                int codigo = int.Parse(Console.ReadLine());
                double preco = 0;
                string lanche = "";
                switch (codigo)
            case 100:
                lanche = "Cachorro Quente";
                preco = 1.10;
                break;
                case 101:
                lanche = "Bauru Simples";
                preco = 1.30;
                break;
            case 102:
                lanche = "Bauru c/ovo";
                preco = 1.50;
                break;
            case 103:
                lanche = "Hamburguer";
                preco = 1.10;
                break;
            case 104:
                lanche = "Cheeseburger";
                preco = 1.30;
                break;
            case 105:
                lanche = "Refigerante";
                preco = 1.00;
                break;

            default:
                Console.WriteLine("Codigo Invalido");
                return;

                Console.WriteLine("Insira a quantidade: ");
                int quantidade = int.Parse(Console.ReadLine());
                double valor_total = preco * quantidade;
                Console.WriteLine("============")
                Console.WriteLine("O codigo pedido foi " + codigo);
                Console.WriteLine("Seu lanche é " + lanche);
                Console.WriteLine("O preco do lanche é de " + preco);
                Console.WriteLine("O valor para ser pago ao total e de " + valor_total);
                Console.WriteLine("==============")
                    Console.WriteLine();


                
           

        }
    }
}
