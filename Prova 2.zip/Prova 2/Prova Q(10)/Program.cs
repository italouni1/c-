﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova_Q_10_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira a primeira nota:");
                decimal nota1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Insira a segunda nota:");
                decimal nota2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Insira a terceira nota:");
                decimal nota3 = int.Parse(Console.ReadLine());
            Console.WriteLine("Insira a quarta nota:");
                decimal nota4 = int.Parse(Console.ReadLine());
            Console.WriteLine("===========");
                decimal media = (nota1 + nota2 + nota3 + nota4) / 4;

                if (media >= 6)

                Console.WriteLine("A media foi" + media + "Aprovado");

                else

           Console.WriteLine("A media foi" + media + "Reprovado");

                Console.WriteLine("===");


        }
    }
}
