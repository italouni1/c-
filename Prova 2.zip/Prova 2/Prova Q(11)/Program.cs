﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova_Q_11_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Docente nivel 1 R$12,00 por hora/aula");
            Console.WriteLine("Docente nivel 2 R$17,00 por hora/aula");
            Console.WriteLine("Docente nivel 3 R$25,00 por hora/aula");
            Console.WriteLine("==============");
            Console.WriteLine("Insira o seu nivel [1] [2] [3]");
                decimal nivel = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Informe quantas horas voce trabalhou: ");
                double horas = double.Parse(Console.ReadLine());
                double salario = 0;

            if (nivel == 1)
                salario = (horas * 12.00);

            else if (nivel == 2)
                salario = horas * 17.00;

            else
                salario = horas * 25.00;

            Console.WriteLine("O seu" +
                " salario é de: " + salario);

            Console.ReadLine();

        }
    }
}
